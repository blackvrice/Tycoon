﻿using Data;
using Inventory;
using UnityEngine;

namespace Farm
{
    public class CropInstance
    {
        public CropData Data { get; private set; }

        private int growthTick;

        public int GrowthTick => growthTick;
        public int CurrentStage { get; private set; }
        public bool IsReadyToHarvest { get; private set; }
        public bool IsDead { get; private set; }

        // 기존 코드 호환용
        public int currentStage => CurrentStage;
        public bool isReadyToHarvest => IsReadyToHarvest;
        public bool isDead => IsDead;

        public CropInstance(CropData data)
        {
            Data = data;

            growthTick = 0;
            CurrentStage = 0;
            IsReadyToHarvest = false;
            IsDead = false;

            RefreshHarvestState();
        }

        public void OnTick(int currentTick)
        {
            if (Data == null) return;
            if (IsDead || IsReadyToHarvest) return;

            int totalStage = Data.GetTotalGrowthStage();
            int finalStage = Mathf.Max(0, totalStage - 1);

            if (CurrentStage >= finalStage)
            {
                CurrentStage = finalStage;
                IsReadyToHarvest = true;
                return;
            }

            int ticksPerStage = Mathf.Max(1, Data.GetGrowthTicks());

            growthTick++;

            if (growthTick < ticksPerStage)
                return;

            growthTick = 0;
            CurrentStage++;

            if (CurrentStage >= finalStage)
            {
                CurrentStage = finalStage;
                IsReadyToHarvest = true;
            }
        }

        public bool CanHarvest()
        {
            return Data != null &&
                   Data.HarvestItem != null &&
                   !IsDead &&
                   IsReadyToHarvest;
        }

        public ItemStack Harvest()
        {
            if (!CanHarvest()) return null;

            ItemStack result = new ItemStack(Data.HarvestItem, 1);

            // FieldTile에서 currentCrop을 null로 만들지만,
            // CropInstance 단독 사용 시 중복 수확 방지를 위해 상태도 변경
            IsReadyToHarvest = false;

            return result;
        }

        public Sprite GetCurrentSprite()
        {
            if (Data == null) return null;

            int finalStage = Mathf.Max(0, Data.GetTotalGrowthStage() - 1);
            int safeStage = Mathf.Clamp(CurrentStage, 0, finalStage);

            return Data.GetSprite(safeStage);
        }

        public void LoadFromSaveData(int stage, bool readyToHarvest)
        {
            LoadFromSaveData(stage, 0, readyToHarvest);
        }

        public void LoadFromSaveData(int stage, int loadedGrowthTick, bool readyToHarvest)
        {
            if (Data == null) return;

            int totalStage = Data.GetTotalGrowthStage();
            int finalStage = Mathf.Max(0, totalStage - 1);

            CurrentStage = Mathf.Clamp(stage, 0, finalStage);
            growthTick = Mathf.Max(0, loadedGrowthTick);
            IsDead = false;

            IsReadyToHarvest = readyToHarvest || CurrentStage >= finalStage;

            if (IsReadyToHarvest)
            {
                CurrentStage = finalStage;
                growthTick = 0;
            }
        }

        public void Kill()
        {
            IsDead = true;
            IsReadyToHarvest = false;
        }

        private void RefreshHarvestState()
        {
            if (Data == null) return;

            int finalStage = Mathf.Max(0, Data.GetTotalGrowthStage() - 1);

            if (CurrentStage >= finalStage)
            {
                CurrentStage = finalStage;
                IsReadyToHarvest = true;
            }
        }
    }
}