﻿using Data;
using Inventory;
using UnityEngine;

namespace Farm
{
    public class FieldTileDebugTester : MonoBehaviour
    {
        [Header("Test Data")]
        [SerializeField] private CropData testCropData;

        [Header("Tick Test")]
        [SerializeField] private int testTickCount = 100;
        

        private FieldTile fieldTile;

        private void Start()
        {
            RunFieldTileTest();
        }

        private void RunFieldTileTest()
        {
            Debug.Log("========== FieldTile Debug Test Start ==========");

            fieldTile = new FieldTile(new Vector2Int(0, 0));

            PrintState("초기 상태");

            TestTill();
            TestPlant();
            TestWater();
            TestGrowthTicks();
            TestHarvest();

            Debug.Log("========== FieldTile Debug Test End ==========");
        }

        private void TestTill()
        {
            Debug.Log("[TEST] 밭 갈기 테스트");

            bool result = fieldTile.Till();

            Debug.Log($"Till Result: {result}");
            PrintState("Till 이후");

            Debug.Assert(result == true, "Till 실패");
            Debug.Assert(fieldTile.State == Enums.TileState.Tiled, "TileState가 Tiled가 아님");
        }

        private void TestPlant()
        {
            Debug.Log("[TEST] 작물 심기 테스트");

            if (testCropData == null)
            {
                Debug.LogError("testCropData가 연결되지 않았습니다. Inspector에서 CropData를 넣어주세요.");
                return;
            }

            bool result = fieldTile.Plant(testCropData);

            Debug.Log($"Plant Result: {result}");
            PrintState("Plant 이후");

            Debug.Assert(result == true, "Plant 실패");
            Debug.Assert(fieldTile.State == Enums.TileState.Planted, "TileState가 Planted가 아님");
            Debug.Assert(fieldTile.CurrentCrop != null, "CurrentCrop이 null임");
            Debug.Assert(fieldTile.IsOccupied == true, "IsOccupied가 true가 아님");
        }

        private void TestWater()
        {
            Debug.Log("[TEST] 물주기 테스트");

            bool result = fieldTile.Water();

            Debug.Log($"Water Result: {result}");
            PrintState("Water 이후");

            Debug.Assert(result == true, "Water 실패");
            Debug.Assert(fieldTile.IsWatered == true, "IsWatered가 true가 아님");
        }

        private void TestGrowthTicks()
        {
            Debug.Log("[TEST] 성장 Tick 테스트");

            for (int i = 0; i < testTickCount; i++)
            {
                fieldTile.OnTick(i);

                Debug.Log(
                    $"Tick: {i}, " +
                    $"State: {fieldTile.State}, " +
                    $"IsWatered: {fieldTile.IsWatered}, " +
                    $"CanHarvest: {fieldTile.CanHarvest()}"
                );

                if (fieldTile.CanHarvest())
                {
                    Debug.Log($"수확 가능 상태 도달 Tick: {i}");
                    break;
                }
            }

            PrintState("Tick 테스트 이후");

            if (fieldTile.CanHarvest())
            {
                Debug.Assert(fieldTile.State == Enums.TileState.Grown, "수확 가능하지만 State가 Grown이 아님");
            }
            else
            {
                Debug.LogWarning("testTickCount 안에 수확 가능 상태가 되지 않았습니다. CropData의 성장 Tick 값을 확인하세요.");
            }
        }

        private void TestHarvest()
        {
            Debug.Log("[TEST] 수확 테스트");

            if (!fieldTile.CanHarvest())
            {
                Debug.LogWarning("아직 수확할 수 없습니다. Harvest 테스트를 건너뜁니다.");
                return;
            }

            ItemStack result = fieldTile.Harvest();

            Debug.Log($"Harvest Result: {(result != null ? "Success" : "Failed")}");

            if (result != null)
            {
                Debug.Log($"Harvest Item: {result.itemData.name}, Amount: {result.amount}");
            }

            PrintState("Harvest 이후");

            Debug.Assert(result != null, "Harvest 결과가 null임");
            Debug.Assert(fieldTile.State == Enums.TileState.Empty, "Harvest 이후 State가 Empty가 아님");
            Debug.Assert(fieldTile.CurrentCrop == null, "Harvest 이후 CurrentCrop이 null이 아님");
            Debug.Assert(fieldTile.IsOccupied == false, "Harvest 이후 IsOccupied가 false가 아님");
        }

        private void PrintState(string title)
        {
            Debug.Log(
                $"[{title}] " +
                $"Position: {fieldTile.GridPosition}, " +
                $"State: {fieldTile.State}, " +
                $"IsWatered: {fieldTile.IsWatered}, " +
                $"IsOccupied: {fieldTile.IsOccupied}, " +
                $"HasCrop: {fieldTile.CurrentCrop != null}, " +
                $"CanHarvest: {fieldTile.CanHarvest()}"
            );
        }
    }
}