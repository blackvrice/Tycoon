﻿using System;
using System.Collections.Generic;
using Data;
using Enums;
using Inventory;
using Runtime;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace Farm
{
    public class FarmGrid
    {
        private readonly int _width;
        private readonly int _height;
        private readonly FieldTile[,] _tiles;

        private readonly Tilemap _groundTilemap;
        private readonly Tilemap _cropTilemap;

        public int Width => _width;
        public int Height => _height;

        public FarmGrid(
            int width,
            int height,
            Tilemap groundTilemap = null,
            Tilemap cropTilemap = null)
        {
            if (width <= 0)
                throw new ArgumentOutOfRangeException(nameof(width), "Width must be greater than 0.");

            if (height <= 0)
                throw new ArgumentOutOfRangeException(nameof(height), "Height must be greater than 0.");

            _width = width;
            _height = height;

            _groundTilemap = groundTilemap;
            _cropTilemap = cropTilemap;

            _tiles = new FieldTile[_width, _height];

            InitializeGrid();
        }

        public bool IsValidPosition(Vector2Int pos)
        {
            return pos.x >= 0 &&
                   pos.x < _width &&
                   pos.y >= 0 &&
                   pos.y < _height;
        }

        public FieldTile GetTile(Vector2Int pos)
        {
            if (!IsValidPosition(pos))
                return null;

            return _tiles[pos.x, pos.y];
        }

        public bool TillTile(Vector2Int pos)
        {
            FieldTile tile = GetTile(pos);

            if (tile == null)
                return false;

            bool result = tile.Till();

            if (result)
                RefreshTileVisual(pos);

            return result;
        }

        public bool PlantCrop(Vector2Int pos, CropData cropData)
        {
            FieldTile tile = GetTile(pos);

            if (tile == null)
                return false;

            bool result = tile.Plant(cropData);

            if (result)
                RefreshTileVisual(pos);

            return result;
        }

        public bool WaterTile(Vector2Int pos)
        {
            FieldTile tile = GetTile(pos);

            if (tile == null)
                return false;

            bool result = tile.Water();

            if (result)
                RefreshTileVisual(pos);

            return result;
        }

        public ItemStack HarvestCrop(Vector2Int pos)
        {
            FieldTile tile = GetTile(pos);

            if (tile == null)
                return null;

            ItemStack result = tile.Harvest();

            if (result != null)
                RefreshTileVisual(pos);

            return result;
        }

        public void ClearTile(Vector2Int pos)
        {
            FieldTile tile = GetTile(pos);

            if (tile == null)
                return;

            tile.Clear();
            RefreshTileVisual(pos);
        }

        public void OnTick(int currentTick)
        {
            for (int x = 0; x < _width; x++)
            {
                for (int y = 0; y < _height; y++)
                {
                    FieldTile tile = _tiles[x, y];

                    if (tile == null)
                        continue;

                    TileState beforeState = tile.State;
                    Sprite beforeSprite = tile.GetCropSprite();

                    tile.OnTick(currentTick);

                    TileState afterState = tile.State;
                    Sprite afterSprite = tile.GetCropSprite();

                    if (beforeState != afterState || beforeSprite != afterSprite)
                    {
                        RefreshTileVisual(new Vector2Int(x, y));
                    }
                }
            }
        }

        public void ResetAllWater()
        {
            for (int x = 0; x < _width; x++)
            {
                for (int y = 0; y < _height; y++)
                {
                    FieldTile tile = _tiles[x, y];

                    if (tile == null)
                        continue;

                    if (!tile.IsWatered)
                        continue;

                    tile.ResetWater();
                    RefreshTileVisual(new Vector2Int(x, y));
                }
            }
        }

        public List<FieldTileSaveData> CreateSaveData()
        {
            List<FieldTileSaveData> saveTiles = new();

            for (int x = 0; x < _width; x++)
            {
                for (int y = 0; y < _height; y++)
                {
                    FieldTile tile = _tiles[x, y];

                    if (tile == null)
                        continue;

                    if (IsDefaultTile(tile))
                        continue;

                    CropInstance crop = tile.CurrentCrop;
                    CropData cropData = crop != null ? crop.Data : null;

                    FieldTileSaveData saveData = new FieldTileSaveData
                    {
                        x = x,
                        y = y,

                        state = tile.State,
                        isWatered = tile.IsWatered,

                        cropId = GetCropId(cropData),
                        cropStage = crop != null ? crop.currentStage : 0,
                        isReadyToHarvest = crop != null && crop.isReadyToHarvest
                    };

                    saveTiles.Add(saveData);
                }
            }

            return saveTiles;
        }

        public void LoadFromSaveData(
            List<FieldTileSaveData> saveTiles,
            Func<string, CropData> cropResolver)
        {
            InitializeGrid();

            if (saveTiles == null)
            {
                RefreshAllTileVisuals();
                return;
            }

            foreach (FieldTileSaveData saveTile in saveTiles)
            {
                if (saveTile == null)
                    continue;

                Vector2Int pos = new Vector2Int(saveTile.x, saveTile.y);

                if (!IsValidPosition(pos))
                    continue;

                FieldTile tile = GetTile(pos);

                if (tile == null)
                    continue;

                CropData cropData = null;

                if (!string.IsNullOrWhiteSpace(saveTile.cropId) && cropResolver != null)
                {
                    cropData = cropResolver.Invoke(saveTile.cropId);
                }

                tile.LoadFromSaveData(
                    saveTile.state,
                    saveTile.isWatered,
                    cropData,
                    saveTile.cropStage,
                    saveTile.isReadyToHarvest
                );
            }

            RefreshAllTileVisuals();
        }

        public void LoadFromSaveData(
            List<FieldTileSaveData> saveTiles,
            Dictionary<string, CropData> cropDatabase)
        {
            LoadFromSaveData(saveTiles, cropId =>
            {
                if (cropDatabase == null)
                    return null;

                return cropDatabase.TryGetValue(cropId, out CropData cropData)
                    ? cropData
                    : null;
            });
        }

        public void ClearAll()
        {
            InitializeGrid();
            RefreshAllTileVisuals();
        }

        private bool IsDefaultTile(FieldTile tile)
        {
            return tile.State == TileState.Empty &&
                   !tile.IsWatered &&
                   tile.CurrentCrop == null;
        }

        private string GetCropId(CropData cropData)
        {
            if (cropData == null)
                return string.Empty;

            return cropData.name;
        }

        private void InitializeGrid()
        {
            for (int x = 0; x < _width; x++)
            {
                for (int y = 0; y < _height; y++)
                {
                    _tiles[x, y] = new FieldTile(new Vector2Int(x, y));
                }
            }
        }

        private void RefreshAllTileVisuals()
        {
            for (int x = 0; x < _width; x++)
            {
                for (int y = 0; y < _height; y++)
                {
                    RefreshTileVisual(new Vector2Int(x, y));
                }
            }
        }

        private void RefreshTileVisual(Vector2Int pos)
        {
            FieldTile tile = GetTile(pos);

            if (tile == null)
                return;

            Vector3Int cellPos = new Vector3Int(pos.x, pos.y, 0);

            /*
             * 현재 FarmGrid는 Tilemap 참조만 가지고 있고,
             * 실제 TileBase 리소스는 아직 받지 않는 구조다.
             *
             * 그래서 지금은 구조만 유지하고,
             * 나중에 TileBase를 연결하면 아래 방식으로 확장하면 된다.
             *
             * 예시:
             *
             * switch (tile.State)
             * {
             *     case TileState.Empty:
             *         _groundTilemap?.SetTile(cellPos, emptyTile);
             *         _cropTilemap?.SetTile(cellPos, null);
             *         break;
             *
             *     case TileState.Tiled:
             *         _groundTilemap?.SetTile(cellPos, tilledTile);
             *         _cropTilemap?.SetTile(cellPos, null);
             *         break;
             *
             *     case TileState.Planted:
             *     case TileState.Grown:
             *         _groundTilemap?.SetTile(cellPos, tilledTile);
             *         _cropTilemap?.SetTile(cellPos, cropTile);
             *         break;
             * }
             */

            // 아직 실제 타일 리소스를 연결하지 않았으므로 현재는 아무 작업도 하지 않음.
        }
    }
}