﻿using Data;
using Enums;
using Inventory;
using UnityEngine;

namespace Farm
{
    public class FieldTile
    {
        private readonly Vector2Int gridPosition;
        private TileState state;
        private bool isWatered;
        private CropInstance currentCrop;

        public Vector2Int GridPosition => gridPosition;
        public TileState State => state;
        public bool IsWatered => isWatered;
        public bool IsOccupied => currentCrop != null;
        public CropInstance CurrentCrop => currentCrop;

        public FieldTile(Vector2Int gridPosition)
        {
            this.gridPosition = gridPosition;
            state = TileState.Empty;
            isWatered = false;
            currentCrop = null;
        }

        public bool CanTill()
        {
            return state == TileState.Empty && currentCrop == null;
        }

        public bool Till()
        {
            if (!CanTill()) return false;

            state = TileState.Tiled;
            isWatered = false;
            currentCrop = null;

            return true;
        }

        public bool CanPlant()
        {
            return state == TileState.Tiled && currentCrop == null;
        }

        public bool CanPlant(CropData cropData)
        {
            return cropData != null && CanPlant();
        }

        public bool Plant(CropData cropData)
        {
            if (!CanPlant(cropData)) return false;

            currentCrop = new CropInstance(cropData);
            state = TileState.Planted;
            isWatered = false;

            return true;
        }

        public bool CanWater()
        {
            return state == TileState.Planted &&
                   currentCrop != null &&
                   !isWatered;
        }

        public bool Water()
        {
            if (!CanWater()) return false;

            isWatered = true;
            return true;
        }

        public bool CanHarvest()
        {
            return currentCrop != null &&
                   currentCrop.CanHarvest();
        }

        public ItemStack Harvest()
        {
            if (!CanHarvest()) return null;

            ItemStack result = currentCrop.Harvest();
            if (result == null) return null;

            // 수확 후 밭은 갈아진 상태로 유지
            currentCrop = null;
            isWatered = false;
            state = TileState.Tiled;

            return result;
        }

        public void Clear()
        {
            state = TileState.Empty;
            currentCrop = null;
            isWatered = false;
        }

        public void OnTick(int currentTick)
        {
            if (state != TileState.Planted) return;
            if (currentCrop == null) return;
            if (!isWatered) return;

            currentCrop.OnTick(currentTick);

            if (currentCrop.CanHarvest())
            {
                state = TileState.Grown;
            }
        }

        public void ResetWater()
        {
            isWatered = false;
        }

        public Sprite GetCropSprite()
        {
            return currentCrop == null ? null : currentCrop.GetCurrentSprite();
        }

        public void LoadFromSaveData(
            TileState loadedState,
            bool loadedIsWatered,
            CropData cropData,
            int cropStage,
            bool readyToHarvest)
        {
            state = loadedState;
            isWatered = loadedIsWatered;
            currentCrop = null;

            switch (loadedState)
            {
                case TileState.Empty:
                    Clear();
                    return;

                case TileState.Tiled:
                    state = TileState.Tiled;
                    currentCrop = null;
                    return;

                case TileState.Planted:
                case TileState.Grown:
                    if (cropData == null)
                    {
                        state = TileState.Tiled;
                        currentCrop = null;
                        isWatered = false;
                        return;
                    }

                    currentCrop = new CropInstance(cropData);
                    currentCrop.LoadFromSaveData(
                        cropStage,
                        readyToHarvest || loadedState == TileState.Grown
                    );

                    state = currentCrop.CanHarvest()
                        ? TileState.Grown
                        : TileState.Planted;

                    return;

                default:
                    Clear();
                    return;
            }
        }
    }
}