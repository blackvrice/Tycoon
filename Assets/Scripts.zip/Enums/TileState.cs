﻿namespace Enums
{
    public enum TileState
    {
        Empty,
        Tiled,
        Planted,
        Grown
    }
}