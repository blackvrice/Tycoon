﻿public enum ItemType
{
    None = 0,
    Stone,
    Stick,
    Wood,
    Hoe,
    WateringCan,
    Axe
}