﻿using System;
using Inventory;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace UI
{
    public class InventorySlotUI : MonoBehaviour
    {
        [SerializeField] private Image iconImage;
        [SerializeField] private TextMeshProUGUI amountText;
        [SerializeField] private Button button;
        [SerializeField] private GameObject selectedFrame;

        private int slotIndex;

        public event Action<int> Clicked;

        private void Awake()
        {
            button.onClick.AddListener(OnClick);
        }

        public void Init(int index)
        {
            slotIndex = index;
        }

        public void Refresh(InventorySlot slot)
        {
            if (slot == null || slot.IsEmpty())
            {
                iconImage.enabled = false;
                iconImage.sprite = null;
                amountText.text = string.Empty;
                return;
            }

            iconImage.enabled = true;
            iconImage.sprite = slot.stack.itemData.Icon;
            amountText.text = slot.stack.amount > 1
                ? slot.stack.amount.ToString()
                : string.Empty;
        }

        public void SetSelected(bool isSelected)
        {
            if (selectedFrame != null)
                selectedFrame.SetActive(isSelected);
        }

        private void OnClick()
        {
            Clicked?.Invoke(slotIndex);
        }
    }
}