﻿namespace UI
{
    public class FarmTileView
    {
        
    }
}