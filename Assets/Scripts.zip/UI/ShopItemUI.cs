﻿using System;
using Data;
using Shop;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace UI
{
    public class ShopItemUI : MonoBehaviour
    {
        [SerializeField] private Image iconImage;
        [SerializeField] private TextMeshProUGUI nameText;
        [SerializeField] private TextMeshProUGUI priceText;
        [SerializeField] private Button buyButton;

        private ShopItemData _shopItem;

        public event Action<ShopItemData> BuyClicked;

        private void Awake()
        {
            buyButton.onClick.AddListener(OnBuyClicked);
        }

        public void Init(ShopItemData item)
        {
            _shopItem = item;

            iconImage.sprite = item.Item.Icon;
            nameText.text = item.Item.name;
            priceText.text = $"{item.BuyPrice} G";
        }

        private void OnBuyClicked()
        {
            BuyClicked?.Invoke(_shopItem);
        }
    }
}