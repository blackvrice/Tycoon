﻿using System.Collections.Generic;
using Inventory;
using UnityEngine;

namespace UI
{
    public class InventoryUI : MonoBehaviour
    {
        [SerializeField] private GameObject rootPanel;
        [SerializeField] private Transform slotParent;
        [SerializeField] private InventorySlotUI slotPrefab;

        private Inventory.Inventory inventory;
        private readonly List<InventorySlotUI> slotUIs = new();

        private int selectedSlotIndex = -1;

        public void Init(Inventory.Inventory inventory)
        {
            this.inventory = inventory;

            CreateSlots();
            Refresh();
            Close();
        }

        private void CreateSlots()
        {
            foreach (Transform child in slotParent)
            {
                Destroy(child.gameObject);
            }

            slotUIs.Clear();

            for (int i = 0; i < inventory.capacity; i++)
            {
                InventorySlotUI slotUI = Instantiate(slotPrefab, slotParent);
                slotUI.Init(i);
                slotUI.Clicked += OnSlotClicked;

                slotUIs.Add(slotUI);
            }
        }

        public void Refresh()
        {
            if (inventory == null) return;

            for (int i = 0; i < slotUIs.Count; i++)
            {
                slotUIs[i].Refresh(inventory.GetSlot(i));
                slotUIs[i].SetSelected(i == selectedSlotIndex);
            }
        }

        private void OnSlotClicked(int slotIndex)
        {
            if (selectedSlotIndex < 0)
            {
                selectedSlotIndex = slotIndex;
                Refresh();
                return;
            }

            if (selectedSlotIndex == slotIndex)
            {
                selectedSlotIndex = -1;
                Refresh();
                return;
            }

            inventory.MoveItem(selectedSlotIndex, slotIndex, int.MaxValue);

            selectedSlotIndex = -1;
            Refresh();
        }

        public void Open()
        {
            rootPanel.SetActive(true);
            Refresh();
        }

        public void Close()
        {
            rootPanel.SetActive(false);
        }

        public void Toggle()
        {
            if (rootPanel.activeSelf)
                Close();
            else
                Open();
        }
    }
}