﻿namespace UI
{
    public class HUDUI
    {
        
    }
}