﻿using System.Collections.Generic;
using Core;
using Data;
using Inventory;
using UnityEngine;
using UnityEngine.UIElements;

namespace UI
{
    [RequireComponent(typeof(UIDocument))]
    public class InventoryShopUIDocumentController : MonoBehaviour
    {
        [Header("Debug Init")]
        [SerializeField] private bool createDebugRuntimeData = true;
        [SerializeField] private int inventoryCapacity = 18;
        [SerializeField] private int startGold = 100;

        [Header("Shop")]
        [SerializeField] private List<ShopItemData> shopItems = new();

        private UIDocument uiDocument;

        private VisualElement root;
        private VisualElement inventoryPanel;
        private VisualElement shopPanel;
        private VisualElement inventoryGrid;
        private VisualElement shopList;

        private Label goldLabel;
        private Label shopMessageLabel;

        private Button inventoryCloseButton;
        private Button shopCloseButton;

        private Inventory.Inventory inventory;
        private EconomyManager economyManager;

        private readonly List<VisualElement> slotElements = new();
        private int selectedSlotIndex = -1;

        public void Init(
            Inventory.Inventory inventory,
            EconomyManager economyManager,
            List<ShopItemData> shopItems)
        {
            this.inventory = inventory;
            this.economyManager = economyManager;
            this.shopItems = shopItems;

            BuildInventorySlots();
            BuildShopItems();
            RefreshAll();
        }

        private void Awake()
        {
            uiDocument = GetComponent<UIDocument>();

            root = uiDocument.rootVisualElement.Q<VisualElement>("Root");

            inventoryPanel = root.Q<VisualElement>("InventoryPanel");
            shopPanel = root.Q<VisualElement>("ShopPanel");

            inventoryGrid = root.Q<VisualElement>("InventoryGrid");
            shopList = root.Q<VisualElement>("ShopList");

            goldLabel = root.Q<Label>("GoldLabel");
            shopMessageLabel = root.Q<Label>("ShopMessageLabel");

            inventoryCloseButton = root.Q<Button>("InventoryCloseButton");
            shopCloseButton = root.Q<Button>("ShopCloseButton");

            inventoryCloseButton.clicked += CloseInventory;
            shopCloseButton.clicked += CloseShop;

            if (createDebugRuntimeData)
            {
                inventory = new Inventory.Inventory(inventoryCapacity);
                economyManager = new EconomyManager(startGold);

                AddDebugShopItemsToInventory();
            }

            BuildInventorySlots();
            BuildShopItems();
            RefreshAll();
        }

        private void Update()
        {
            if (UnityEngine.Input.GetKeyDown(KeyCode.I))
            {
                ToggleInventory();
            }

            if (UnityEngine.Input.GetKeyDown(KeyCode.B))
            {
                ToggleShop();
            }

            if (UnityEngine.Input.GetKeyDown(KeyCode.Escape))
            {
                CloseInventory();
                CloseShop();
            }
        }

        private void BuildInventorySlots()
        {
            if (inventory == null || inventoryGrid == null)
                return;

            inventoryGrid.Clear();
            slotElements.Clear();

            for (int i = 0; i < inventory.capacity; i++)
            {
                int slotIndex = i;

                VisualElement slotElement = new VisualElement();
                slotElement.AddToClassList("inventory-slot");

                Image icon = new Image();
                icon.name = "Icon";
                icon.AddToClassList("slot-icon");

                Label emptyLabel = new Label("-");
                emptyLabel.name = "EmptyLabel";
                emptyLabel.AddToClassList("slot-empty-label");

                Label amountLabel = new Label();
                amountLabel.name = "Amount";
                amountLabel.AddToClassList("slot-amount");

                slotElement.Add(icon);
                slotElement.Add(emptyLabel);
                slotElement.Add(amountLabel);

                slotElement.RegisterCallback<ClickEvent>(_ =>
                {
                    OnInventorySlotClicked(slotIndex);
                });

                inventoryGrid.Add(slotElement);
                slotElements.Add(slotElement);
            }
        }

        private void BuildShopItems()
        {
            if (shopList == null)
                return;

            shopList.Clear();

            if (shopItems == null)
                return;

            foreach (ShopItemData shopItem in shopItems)
            {
                if (shopItem == null)
                    continue;

                VisualElement row = CreateShopItemRow(shopItem);
                shopList.Add(row);
            }
        }

        private VisualElement CreateShopItemRow(ShopItemData shopItem)
        {
            VisualElement row = new VisualElement();
            row.AddToClassList("shop-item-row");

            if (!shopItem.IsUnlocked)
                row.AddToClassList("locked");

            Image icon = new Image();
            icon.AddToClassList("shop-icon");

            if (shopItem.Item != null && shopItem.Item.Icon != null)
            {
                icon.sprite = shopItem.Item.Icon;
            }

            VisualElement info = new VisualElement();
            info.AddToClassList("shop-info");

            string itemName = shopItem.Item != null
                ? shopItem.Item.ItemName
                : "Unknown Item";

            Label nameLabel = new Label(itemName);
            nameLabel.AddToClassList("shop-item-name");

            Label priceLabel = new Label($"Buy {shopItem.BuyPrice} G / Sell {shopItem.SellPrice} G");
            priceLabel.AddToClassList("shop-item-price");

            info.Add(nameLabel);
            info.Add(priceLabel);

            Button buyButton = new Button();
            buyButton.text = shopItem.IsUnlocked ? "Buy" : "Locked";
            buyButton.SetEnabled(shopItem.IsUnlocked);
            buyButton.AddToClassList("buy-button");

            buyButton.clicked += () =>
            {
                BuyItem(shopItem);
            };

            row.Add(icon);
            row.Add(info);
            row.Add(buyButton);

            return row;
        }

        private void OnInventorySlotClicked(int slotIndex)
        {
            if (inventory == null)
                return;

            if (!inventory.IsValidSlot(slotIndex))
                return;

            if (selectedSlotIndex < 0)
            {
                selectedSlotIndex = slotIndex;
                RefreshInventory();
                return;
            }

            if (selectedSlotIndex == slotIndex)
            {
                selectedSlotIndex = -1;
                RefreshInventory();
                return;
            }

            inventory.MoveItem(selectedSlotIndex, slotIndex, int.MaxValue);

            selectedSlotIndex = -1;
            RefreshInventory();
        }

        private void BuyItem(ShopItemData shopItem)
        {
            ClearShopMessage();

            if (inventory == null || economyManager == null)
            {
                ShowShopMessage("시스템이 초기화되지 않았습니다.");
                return;
            }

            if (shopItem == null || shopItem.Item == null)
            {
                ShowShopMessage("아이템 정보가 없습니다.");
                return;
            }

            if (!shopItem.IsUnlocked)
            {
                ShowShopMessage("아직 구매할 수 없는 아이템입니다.");
                return;
            }

            if (!economyManager.CanAfford(shopItem.BuyPrice))
            {
                ShowShopMessage("골드가 부족합니다.");
                return;
            }

            ItemStack stack = new ItemStack(shopItem.Item, 1);

            bool added = inventory.AddItem(stack, 1);

            if (!added)
            {
                ShowShopMessage("인벤토리 공간이 부족합니다.");
                return;
            }

            economyManager.SpendGold(shopItem.BuyPrice);

            RefreshAll();
        }

        private void AddDebugShopItemsToInventory()
        {
            if (inventory == null || shopItems == null)
                return;

            if (shopItems.Count <= 0)
                return;

            ShopItemData firstItem = shopItems[0];

            if (firstItem == null || firstItem.Item == null)
                return;

            ItemStack stack = new ItemStack(firstItem.Item, 3);
            inventory.AddItem(stack, 3);
        }

        private void RefreshAll()
        {
            RefreshGold();
            RefreshInventory();
        }

        private void RefreshGold()
        {
            if (goldLabel == null)
                return;

            int gold = economyManager != null ? economyManager.Gold : 0;
            goldLabel.text = $"Gold: {gold} G";
        }

        private void RefreshInventory()
        {
            if (inventory == null)
                return;

            for (int i = 0; i < slotElements.Count; i++)
            {
                VisualElement slotElement = slotElements[i];

                InventorySlot slot = inventory.GetSlot(i);

                Image icon = slotElement.Q<Image>("Icon");
                Label emptyLabel = slotElement.Q<Label>("EmptyLabel");
                Label amountLabel = slotElement.Q<Label>("Amount");

                slotElement.RemoveFromClassList("selected");

                if (i == selectedSlotIndex)
                {
                    slotElement.AddToClassList("selected");
                }

                if (slot == null || slot.IsEmpty())
                {
                    icon.sprite = null;
                    icon.style.display = DisplayStyle.None;

                    emptyLabel.style.display = DisplayStyle.Flex;
                    amountLabel.text = string.Empty;

                    continue;
                }

                icon.style.display = DisplayStyle.Flex;

                if (slot.stack.itemData != null && slot.stack.itemData.Icon != null)
                {
                    icon.sprite = slot.stack.itemData.Icon;
                }
                else
                {
                    icon.sprite = null;
                }

                emptyLabel.style.display = DisplayStyle.None;

                amountLabel.text = slot.stack.amount > 1
                    ? slot.stack.amount.ToString()
                    : string.Empty;
            }
        }

        private void ShowShopMessage(string message)
        {
            if (shopMessageLabel == null)
                return;

            shopMessageLabel.text = message;
        }

        private void ClearShopMessage()
        {
            if (shopMessageLabel == null)
                return;

            shopMessageLabel.text = string.Empty;
        }

        public void OpenInventory()
        {
            inventoryPanel.RemoveFromClassList("hidden");
            RefreshInventory();
        }

        public void CloseInventory()
        {
            selectedSlotIndex = -1;
            inventoryPanel.AddToClassList("hidden");
        }

        public void ToggleInventory()
        {
            if (inventoryPanel.ClassListContains("hidden"))
                OpenInventory();
            else
                CloseInventory();
        }

        public void OpenShop()
        {
            shopPanel.RemoveFromClassList("hidden");
            RefreshAll();
        }

        public void CloseShop()
        {
            shopPanel.AddToClassList("hidden");
            ClearShopMessage();
        }

        public void ToggleShop()
        {
            if (shopPanel.ClassListContains("hidden"))
                OpenShop();
            else
                CloseShop();
        }
    }
}