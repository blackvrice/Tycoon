﻿namespace Player
{
    public class InteractionController
    {
        
    }
}