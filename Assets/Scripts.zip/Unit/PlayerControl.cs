using Input;
using UnityEngine;

namespace Unit
{
    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(Collider2D))]
    public class PlayerControl : MonoBehaviour
    {
        [SerializeField] private float speed = 5f;
        [SerializeField] private Animator animator;
        [SerializeField] private InputManager inputManager;

        private const int SlotCount = 9;

        private int _selectedSlot = 0;
        private ItemType[] _hotbarItems = new ItemType[SlotCount];

        private Rigidbody2D _rb;
        private Vector2 _moveInput;

        private void Awake()
        {
            _rb = GetComponent<Rigidbody2D>();

            if (animator == null)
                animator = GetComponent<Animator>();
        }

        private void OnEnable()
        {
            if (inputManager == null)
            {
                Debug.LogError("PlayerControl: InputManager가 연결되지 않았습니다.", this);
                enabled = false;
                return;
            }

            inputManager.MoveEvent += OnMove;
            inputManager.SelectHotbarEvent += OnSelectedSlot;
            inputManager.ScrollHotbarEvent += OnScrollSelectedSlot;
        }

        private void OnDisable()
        {
            if (inputManager == null)
                return;

            inputManager.MoveEvent -= OnMove;
            inputManager.SelectHotbarEvent -= OnSelectedSlot;
            inputManager.ScrollHotbarEvent -= OnScrollSelectedSlot;
        }

        private void OnMove(Vector2 input)
        {
            _moveInput = input;

            if (_moveInput.sqrMagnitude > 1f)
                _moveInput = _moveInput.normalized;
        }

        private void OnSelectedSlot(int slotIndex)
        {
            _selectedSlot = WrapIndex(slotIndex, SlotCount);
        }

        private void OnScrollSelectedSlot(int delta)
        {
            _selectedSlot = WrapIndex(_selectedSlot + delta, SlotCount);
        }

        private void Update()
        {
            bool isMoving = _moveInput.sqrMagnitude > 0.01f;

            if (animator == null)
                return;

            animator.SetBool("IsMove", isMoving);
            animator.SetFloat("MoveX", _moveInput.x);
            animator.SetFloat("MoveY", _moveInput.y);

            if (isMoving)
            {
                animator.SetFloat("LastMoveX", _moveInput.x);
                animator.SetFloat("LastMoveY", _moveInput.y);
            }
        }

        private void FixedUpdate()
        {
            Vector2 nextPosition = _rb.position + _moveInput * speed * Time.fixedDeltaTime;
            _rb.MovePosition(nextPosition);
        }

        private int WrapIndex(int index, int count)
        {
            return (index % count + count) % count;
        }
    }
}