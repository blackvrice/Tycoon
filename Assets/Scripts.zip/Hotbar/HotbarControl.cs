using Input;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Serialization;
using UnityEngine.UIElements;

public class HotbarControl : MonoBehaviour
{
    [SerializeField] private UIDocument uiDocument;
    [SerializeField] private InputManager inputManager;

    [Header("Test Sprites")]
    [SerializeField] private Sprite stoneSprite;
    [SerializeField] private Sprite stickSprite;
    [SerializeField] private Sprite woodSprite;
    [SerializeField] private Sprite hoeSprite;
    [SerializeField] private Sprite wateringCanSprite;
    [SerializeField] private Sprite axeSprite;

    private const int SlotCount = 9;

    private VisualElement[] _slots;
    private VisualElement[] _icons;
    private int _selectedIndex;

    private void Awake()
    {
        if (uiDocument == null)
            uiDocument = GetComponent<UIDocument>();
    }

    private void OnEnable()
    {
        if (uiDocument == null || inputManager == null)
        {
            Debug.LogError("HotbarControl 참조가 비어 있습니다.", this);
            enabled = false;
            return;
        }

        BindUI();

        inputManager.SelectHotbarEvent += SetSelected;
        inputManager.ScrollHotbarEvent += OnScrollHotbar;
        RefreshSelection();

        // 테스트용
        SetItemIcon(0, ItemType.Stone);
        SetItemIcon(1, ItemType.Stick);
        SetItemIcon(2, ItemType.Wood);
        SetItemIcon(3, ItemType.Axe);
    }

    private void OnDisable()
    {
        if (inputManager != null)
            inputManager.SelectHotbarEvent -= SetSelected;
    }
    
    private void BindUI()
    {
        var root = uiDocument.rootVisualElement;

        _slots = new VisualElement[SlotCount];
        _icons = new VisualElement[SlotCount];

        for (int i = 0; i < SlotCount; i++)
        {
            _slots[i] = root.Q<VisualElement>($"slot{i}");
            _icons[i] = root.Q<VisualElement>($"icon{i}");
        }
    }
    
    private void OnScrollHotbar(int delta)
    {
        SetSelected(_selectedIndex + delta);
    }

    private void SetSelected(int index)
    {
        _selectedIndex = WrapIndex(index, SlotCount);
        RefreshSelection();
    }

    private void RefreshSelection()
    {
        for (int i = 0; i < _slots.Length; i++)
        {
            if (i == _selectedIndex)
                _slots[i].AddToClassList("selected");
            else
                _slots[i].RemoveFromClassList("selected");
        }
    }

    public void SetItemIcon(int slotIndex, ItemType itemType)
    {
        if (!IsValidIndex(slotIndex) || _icons[slotIndex] == null)
            return;

        Sprite sprite = itemType switch
        {
            ItemType.Stone => stoneSprite,
            ItemType.Stick => stickSprite,
            ItemType.Wood => woodSprite,
            ItemType.Hoe => hoeSprite,
            ItemType.Axe => axeSprite,
            ItemType.WateringCan => wateringCanSprite,
            _ => null
        };

        _icons[slotIndex].style.backgroundImage =
            sprite != null ? new StyleBackground(sprite) : StyleKeyword.None;
    }

    public void ClearItemIcon(int slotIndex)
    {
        if (!IsValidIndex(slotIndex) || _icons[slotIndex] == null)
            return;

        _icons[slotIndex].style.backgroundImage = StyleKeyword.None;
    }

    private bool IsValidIndex(int index)
    {
        return index >= 0 && index < SlotCount;
    }

    private int WrapIndex(int index, int count)
    {
        return (index % count + count) % count;
    }
}