﻿namespace Inventory
{
    public class InventorySlot
    {
        public ItemStack stack { get; private set; }

        public bool IsEmpty()
        {
            return stack == null || stack.IsEmpty();
        }

        public void SetItem(ItemStack stack, int amount)
        {
            if (stack == null || stack.itemData == null || amount <= 0)
            {
                Clear();
                return;
            }

            int finalAmount = amount;
            int maxStack = stack.itemData.MaxStack;

            if (finalAmount > maxStack)
                finalAmount = maxStack;

            this.stack = new ItemStack(stack.itemData, finalAmount);
        }

        public int AddItem(ItemStack stack, int amount)
        {
            if (stack == null || stack.itemData == null || amount <= 0)
                return amount;

            if (IsEmpty())
            {
                int addAmount = amount;
                int maxStack = stack.itemData.MaxStack;

                if (addAmount > maxStack)
                    addAmount = maxStack;

                this.stack = new ItemStack(stack.itemData, addAmount);
                return amount - addAmount;
            }

            if (!this.stack.CanMerge(stack))
                return amount;

            int current = this.stack.amount;
            int max = this.stack.itemData.MaxStack;
            int canAdd = max - current;

            if (canAdd <= 0)
                return amount;

            int addValue = amount > canAdd ? canAdd : amount;
            this.stack.AddAmount(addValue);

            return amount - addValue;
        }

        public int RemoveItem(int amount)
        {
            if (stack == null || amount <= 0)
                return 0;

            int removeValue = amount > stack.amount ? stack.amount : amount;
            stack.RemoveAmount(removeValue);

            if (stack.IsEmpty())
            {
                Clear();
            }

            return removeValue;
        }

        public void Clear()
        {
            stack = null;
        }
    }
}