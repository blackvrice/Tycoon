﻿using System;
using System.Collections.Generic;
using Data;
using Runtime;

namespace Inventory
{
    public class Inventory
    {
        // 기존 UI 코드 호환용
        public List<InventorySlot> slots { get; } = new();
        public int capacity { get; }

        // C# 스타일 접근용
        public IReadOnlyList<InventorySlot> Slots => slots;
        public int Capacity => capacity;

        public Inventory(int capacity)
        {
            if (capacity <= 0)
                throw new ArgumentOutOfRangeException(nameof(capacity), "Inventory capacity must be greater than 0.");

            this.capacity = capacity;

            for (int i = 0; i < capacity; i++)
            {
                slots.Add(new InventorySlot());
            }
        }

        public bool IsValidSlot(int slot)
        {
            return slot >= 0 && slot < capacity;
        }

        public InventorySlot GetSlot(int slot)
        {
            if (!IsValidSlot(slot))
                return null;

            return slots[slot];
        }

        public ItemData GetSelectedItem(int slot)
        {
            InventorySlot inventorySlot = GetSlot(slot);

            if (inventorySlot == null)
                return null;

            if (inventorySlot.IsEmpty())
                return null;

            return inventorySlot.stack.itemData;
        }

        public int GetAmount(int slot)
        {
            InventorySlot inventorySlot = GetSlot(slot);

            if (inventorySlot == null)
                return 0;

            if (inventorySlot.IsEmpty())
                return 0;

            return inventorySlot.stack.amount;
        }

        public bool AddItemToSlot(int slot, ItemStack item, int amount)
        {
            if (!IsValidSlot(slot))
                return false;

            if (item == null || item.itemData == null || amount <= 0)
                return false;

            int remaining = slots[slot].AddItem(item, amount);
            return remaining == 0;
        }

        public bool AddItemToSlot(int slot, ItemData itemData, int amount)
        {
            if (itemData == null || amount <= 0)
                return false;

            return AddItemToSlot(slot, new ItemStack(itemData, amount), amount);
        }

        public bool AddItem(ItemStack item, int amount)
        {
            if (item == null || item.itemData == null || amount <= 0)
                return false;

            int remaining = amount;

            // 1. 기존 스택에 먼저 병합
            for (int i = 0; i < capacity; i++)
            {
                InventorySlot slot = slots[i];

                if (slot == null || slot.IsEmpty())
                    continue;

                int before = remaining;
                remaining = slot.AddItem(item, remaining);

                if (remaining == 0)
                    return true;

                // 변화가 없으면 다음 슬롯으로 진행
                if (remaining == before)
                    continue;
            }

            // 2. 빈 슬롯에 추가
            for (int i = 0; i < capacity; i++)
            {
                InventorySlot slot = slots[i];

                if (slot == null)
                {
                    slots[i] = new InventorySlot();
                    slot = slots[i];
                }

                if (!slot.IsEmpty())
                    continue;

                remaining = slot.AddItem(item, remaining);

                if (remaining == 0)
                    return true;
            }

            return false;
        }

        public bool AddItem(ItemData itemData, int amount)
        {
            if (itemData == null || amount <= 0)
                return false;

            return AddItem(new ItemStack(itemData, amount), amount);
        }

        public bool RemoveItemFromSlot(int slot, int amount)
        {
            if (!IsValidSlot(slot))
                return false;

            if (amount <= 0)
                return false;

            InventorySlot inventorySlot = slots[slot];

            if (inventorySlot == null || inventorySlot.IsEmpty())
                return false;

            int removed = inventorySlot.RemoveItem(amount);
            return removed > 0;
        }

        public bool RemoveItemFromSlot(int slot, ItemData itemData, int amount)
        {
            if (!IsValidSlot(slot))
                return false;

            if (itemData == null || amount <= 0)
                return false;

            InventorySlot inventorySlot = slots[slot];

            if (inventorySlot == null || inventorySlot.IsEmpty())
                return false;

            if (!IsSameItem(inventorySlot.stack.itemData, itemData))
                return false;

            int removed = inventorySlot.RemoveItem(amount);
            return removed > 0;
        }

        public bool RemoveItem(ItemData itemData, int amount)
        {
            if (itemData == null || amount <= 0)
                return false;

            if (!HasItem(itemData, amount))
                return false;

            int remaining = amount;

            for (int i = 0; i < capacity; i++)
            {
                InventorySlot slot = slots[i];

                if (slot == null || slot.IsEmpty())
                    continue;

                if (!IsSameItem(slot.stack.itemData, itemData))
                    continue;

                int removed = slot.RemoveItem(remaining);
                remaining -= removed;

                if (remaining <= 0)
                    return true;
            }

            return false;
        }

        public bool HasItem(int slot, ItemData itemData, int amount)
        {
            if (!IsValidSlot(slot))
                return false;

            if (itemData == null || amount <= 0)
                return false;

            InventorySlot inventorySlot = slots[slot];

            if (inventorySlot == null || inventorySlot.IsEmpty())
                return false;

            return IsSameItem(inventorySlot.stack.itemData, itemData) &&
                   inventorySlot.stack.amount >= amount;
        }

        public bool HasItem(ItemData itemData, int amount)
        {
            if (itemData == null || amount <= 0)
                return false;

            int total = GetItemCount(itemData);
            return total >= amount;
        }

        public int GetItemCount(ItemData itemData)
        {
            if (itemData == null)
                return 0;

            int total = 0;

            for (int i = 0; i < capacity; i++)
            {
                InventorySlot slot = slots[i];

                if (slot == null || slot.IsEmpty())
                    continue;

                if (!IsSameItem(slot.stack.itemData, itemData))
                    continue;

                total += slot.stack.amount;
            }

            return total;
        }

        public int FindFirstEmptySlot()
        {
            for (int i = 0; i < capacity; i++)
            {
                InventorySlot slot = slots[i];

                if (slot == null || slot.IsEmpty())
                    return i;
            }

            return -1;
        }

        public int FindFirstSlotWithItem(ItemData itemData)
        {
            if (itemData == null)
                return -1;

            for (int i = 0; i < capacity; i++)
            {
                InventorySlot slot = slots[i];

                if (slot == null || slot.IsEmpty())
                    continue;

                if (IsSameItem(slot.stack.itemData, itemData))
                    return i;
            }

            return -1;
        }

        public bool SwapSlot(int slot1, int slot2)
        {
            if (!IsValidSlot(slot1) || !IsValidSlot(slot2))
                return false;

            if (slot1 == slot2)
                return true;

            (slots[slot1], slots[slot2]) = (slots[slot2], slots[slot1]);
            return true;
        }

        public bool MoveItem(int fromSlot, int toSlot, int amount)
        {
            if (!IsValidSlot(fromSlot) || !IsValidSlot(toSlot))
                return false;

            if (fromSlot == toSlot)
                return true;

            if (amount <= 0)
                return false;

            InventorySlot source = slots[fromSlot];
            InventorySlot target = slots[toSlot];

            if (source == null || source.IsEmpty())
                return false;

            if (target == null)
            {
                target = new InventorySlot();
                slots[toSlot] = target;
            }

            ItemStack sourceStack = source.stack;
            int moveAmount = amount > sourceStack.amount
                ? sourceStack.amount
                : amount;

            if (moveAmount <= 0)
                return false;

            // 1. 대상 슬롯이 비어 있으면 이동
            if (target.IsEmpty())
            {
                target.SetItem(sourceStack, moveAmount);
                source.RemoveItem(moveAmount);
                return true;
            }

            // 2. 같은 아이템이면 병합
            if (target.stack.CanMerge(sourceStack))
            {
                int remaining = target.AddItem(sourceStack, moveAmount);
                int moved = moveAmount - remaining;

                if (moved <= 0)
                    return false;

                source.RemoveItem(moved);
                return true;
            }

            // 3. 일부 이동이 아니라 전체 이동이면 스왑
            if (moveAmount == sourceStack.amount)
            {
                (slots[fromSlot], slots[toSlot]) = (slots[toSlot], slots[fromSlot]);
                return true;
            }

            return false;
        }

        public List<InventorySlotSaveData> CreateSaveData()
        {
            List<InventorySlotSaveData> saveSlots = new();

            for (int i = 0; i < capacity; i++)
            {
                InventorySlot slot = slots[i];

                if (slot == null)
                    continue;

                if (slot.IsEmpty())
                    continue;

                if (slot.stack == null)
                    continue;

                if (slot.stack.itemData == null)
                    continue;

                if (slot.stack.amount <= 0)
                    continue;

                saveSlots.Add(new InventorySlotSaveData
                {
                    slotIndex = i,
                    itemId = GetItemId(slot.stack.itemData),
                    amount = slot.stack.amount
                });
            }

            return saveSlots;
        }

        public void LoadFromSaveData(
            List<InventorySlotSaveData> saveSlots,
            Func<string, ItemData> itemResolver)
        {
            Clear();

            if (saveSlots == null)
                return;

            if (itemResolver == null)
                return;

            foreach (InventorySlotSaveData saveSlot in saveSlots)
            {
                if (saveSlot == null)
                    continue;

                if (!IsValidSlot(saveSlot.slotIndex))
                    continue;

                if (string.IsNullOrWhiteSpace(saveSlot.itemId))
                    continue;

                if (saveSlot.amount <= 0)
                    continue;

                ItemData itemData = itemResolver.Invoke(saveSlot.itemId);

                if (itemData == null)
                    continue;

                ItemStack stack = new ItemStack(itemData, saveSlot.amount);
                slots[saveSlot.slotIndex].SetItem(stack, saveSlot.amount);
            }
        }

        public void LoadFromSaveData(
            List<InventorySlotSaveData> saveSlots,
            Dictionary<string, ItemData> itemDatabase)
        {
            LoadFromSaveData(saveSlots, itemId =>
            {
                if (itemDatabase == null)
                    return null;

                return itemDatabase.TryGetValue(itemId, out ItemData itemData)
                    ? itemData
                    : null;
            });
        }

        public void Clear()
        {
            for (int i = 0; i < capacity; i++)
            {
                slots[i] = new InventorySlot();
            }
        }

        public bool IsFull()
        {
            return FindFirstEmptySlot() == -1;
        }

        private string GetItemId(ItemData itemData)
        {
            if (itemData == null)
                return string.Empty;

            if (!string.IsNullOrWhiteSpace(itemData.ItemId))
                return itemData.ItemId;

            return itemData.name;
        }

        private bool IsSameItem(ItemData a, ItemData b)
        {
            if (a == null || b == null)
                return false;

            string aId = GetItemId(a);
            string bId = GetItemId(b);

            if (!string.IsNullOrWhiteSpace(aId) &&
                !string.IsNullOrWhiteSpace(bId))
            {
                return string.Equals(aId, bId, StringComparison.Ordinal);
            }

            return a == b;
        }
    }
}