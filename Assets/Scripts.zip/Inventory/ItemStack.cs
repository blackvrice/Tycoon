﻿using System;
using Data;

namespace Inventory
{
    public class ItemStack
    {
        public ItemData itemData { get; }

        public int amount { get; private set; }

        public ItemStack(ItemData itemData, int amount)
        {
            if (itemData == null)
                throw new ArgumentNullException(nameof(itemData));

            if (amount < 0)
                throw new ArgumentOutOfRangeException(nameof(amount));

            this.itemData = itemData;
            this.amount = amount;
        }

        public void SetAmount(int amount)
        {
            if (amount < 0)
                throw new ArgumentOutOfRangeException(nameof(amount));

            this.amount = amount;
        }

        public void AddAmount(int amount)
        {
            if (amount < 0)
                throw new ArgumentOutOfRangeException(nameof(amount));

            this.amount += amount;
        }

        public bool RemoveAmount(int amount)
        {
            if (amount < 0)
                throw new ArgumentOutOfRangeException(nameof(amount));

            if (amount > this.amount)
                return false;

            this.amount -= amount;
            return true;
        }

        public bool IsEmpty()
        {
            return amount <= 0;
        }

        public bool CanMerge(ItemData other)
        {
            if (other == null) return false;
            return itemData.CanStackWith(other);
        }

        public bool CanMerge(ItemStack other)
        {
            if (other == null) return false;
            return itemData.CanStackWith(other.itemData);
        }

        public ItemStack Clone()
        {
            return new ItemStack(itemData, amount);
        }
    }
}