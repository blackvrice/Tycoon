﻿using System;
using Enums;

namespace Runtime
{
    [Serializable]
    public class FieldTileSaveData
    {
        public int x;
        public int y;

        public TileState state;
        public bool isWatered;

        public string cropId;
        public int cropStage;
        public bool isReadyToHarvest;
    }
}