﻿using System;
using System.Collections.Generic;

namespace Runtime
{
    [Serializable]
    public class GameSaveData
    {
        public int saveVersion;
        public string savedAt;

        public int currentTick;
        public int currentDay;

        public int gold;

        public List<InventorySlotSaveData> inventorySlots = new();
        public List<FieldTileSaveData> fieldTiles = new();
    }
}