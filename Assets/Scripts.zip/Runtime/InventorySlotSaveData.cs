﻿using System;

namespace Runtime
{
    [Serializable]
    public class InventorySlotSaveData
    {
        public int slotIndex;
        public string itemId;
        public int amount;
    }
}