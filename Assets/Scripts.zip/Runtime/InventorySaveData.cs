﻿using System;
using System.Collections.Generic;

namespace Runtime
{
    [Serializable]
    public class InventorySaveData
    {
        public int capacity;
        public List<InventorySlotSaveData> slots = new();
    }
}