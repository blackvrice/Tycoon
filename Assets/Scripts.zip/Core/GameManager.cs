﻿using Input;
using Player;
using UnityEngine;

namespace Core
{
    public class GameManager : MonoBehaviour
    {
    }
}