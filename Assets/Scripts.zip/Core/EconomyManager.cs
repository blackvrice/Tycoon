﻿namespace Core
{
    public class EconomyManager
    {
        public int Gold => CurrentGold;

        // 기존 코드 호환용
        public int CurrentGold { get; private set; }

        public EconomyManager(int startGold = 0)
        {
            SetGold(startGold);
        }

        public void AddGold(int amount)
        {
            if (amount <= 0) return;

            CurrentGold += amount;
        }

        public bool SpendGold(int amount)
        {
            if (amount <= 0) return false;
            if (amount > CurrentGold) return false;

            CurrentGold -= amount;
            return true;
        }

        public bool CanAfford(int amount)
        {
            return amount >= 0 && CurrentGold >= amount;
        }

        public void SetGold(int amount)
        {
            CurrentGold = amount < 0 ? 0 : amount;
        }
    }
}