﻿using System;
using System.Collections.Generic;
using Systems.Interfaces;
using UnityEngine;

namespace Core
{
    public class TickManager : MonoBehaviour
    {
        [Header("Tick Settings")]
        [SerializeField] private float tickInterval = 0.5f;
        [SerializeField] private int ticksPerDay = 48;
        [SerializeField] private bool autoStart = false;

        [Header("Debug")]
        [SerializeField] private bool enableDebugLog = false;
        [SerializeField] private bool logEveryTick = false;

        private readonly List<ITickable> _tickables = new();
        private readonly List<ITickable> _tickableSnapshot = new();

        private float _elapsedTime;
        private bool _isRunning;
        private bool _isPaused;
        private float _timeScale = 1f;

        public int currentTick { get; private set; }

        public int currentDay
        {
            get
            {
                if (ticksPerDay <= 0) return 0;
                return currentTick / ticksPerDay;
            }
        }

        public int tickInDay
        {
            get
            {
                if (ticksPerDay <= 0) return 0;
                return currentTick % ticksPerDay;
            }
        }

        // C# 스타일 접근용
        public int CurrentTick => currentTick;
        public int CurrentDay => currentDay;
        public int TickInDay => tickInDay;

        public int TicksPerDay => ticksPerDay;
        public float TickInterval => tickInterval;
        public bool IsRunning => _isRunning;
        public bool IsPaused => _isPaused;
        public float TimeScale => _timeScale;
        public int RegisteredCount => _tickables.Count;

        public event Action<int> OnTicked;
        public event Action<int> OnDayChanged;

        private void Awake()
        {
            ClampSettings();
        }

        private void Start()
        {
            if (autoStart)
            {
                StartTick();
            }
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            ClampSettings();
        }
#endif

        public void Register(ITickable tickable)
        {
            if (tickable == null)
                return;

            if (_tickables.Contains(tickable))
                return;

            _tickables.Add(tickable);

            Log($"Register: {tickable.GetType().Name}, Count={_tickables.Count}");
        }

        public void Unregister(ITickable tickable)
        {
            if (tickable == null)
                return;

            if (_tickables.Remove(tickable))
            {
                Log($"Unregister: {tickable.GetType().Name}, Count={_tickables.Count}");
            }
        }

        public void ClearTickables()
        {
            _tickables.Clear();
            _tickableSnapshot.Clear();

            Log("ClearTickables");
        }

        public void StartTick()
        {
            _elapsedTime = 0f;
            _isRunning = true;
            _isPaused = false;

            Log("StartTick");
        }

        public void StopTick()
        {
            _isRunning = false;
            _isPaused = false;
            _elapsedTime = 0f;

            Log("StopTick");
        }

        public void Pause()
        {
            if (!_isRunning)
                return;

            _isPaused = true;

            Log("Pause");
        }

        public void Resume()
        {
            if (!_isRunning)
                return;

            _isPaused = false;

            Log("Resume");
        }

        public void TogglePause()
        {
            if (!_isRunning)
                return;

            if (_isPaused)
                Resume();
            else
                Pause();
        }

        public void SetTimeScale(float scale)
        {
            _timeScale = Mathf.Max(0.1f, scale);

            Log($"SetTimeScale: {_timeScale}");
        }

        public void SetTickInterval(float interval)
        {
            tickInterval = Mathf.Max(0.01f, interval);
            _elapsedTime = 0f;

            Log($"SetTickInterval: {tickInterval}");
        }

        public void SetTicksPerDay(int value)
        {
            ticksPerDay = Mathf.Max(1, value);

            Log($"SetTicksPerDay: {ticksPerDay}");
        }

        public int GetCurrentTick()
        {
            return currentTick;
        }

        public int GetCurrentDay()
        {
            return currentDay;
        }

        public int GetTickInDay()
        {
            return tickInDay;
        }

        public void ResetTick()
        {
            currentTick = 0;
            _elapsedTime = 0f;

            Log("ResetTick");
        }

        public void LoadFromSaveData(int loadedCurrentTick, int loadedCurrentDay)
        {
            int loadedTick = Mathf.Max(0, loadedCurrentTick);

            if (loadedTick <= 0 && loadedCurrentDay > 0 && ticksPerDay > 0)
            {
                loadedTick = loadedCurrentDay * ticksPerDay;
            }

            currentTick = loadedTick;
            _elapsedTime = 0f;

            Log($"LoadFromSaveData: Tick={currentTick}, Day={currentDay}, TickInDay={tickInDay}");
        }

        public void LoadFromSaveData(int loadedCurrentTick)
        {
            currentTick = Mathf.Max(0, loadedCurrentTick);
            _elapsedTime = 0f;

            Log($"LoadFromSaveData: Tick={currentTick}, Day={currentDay}, TickInDay={tickInDay}");
        }

        public void ForceTick()
        {
            Tick();
        }

        public void ForceTicks(int count)
        {
            if (count <= 0)
                return;

            for (int i = 0; i < count; i++)
            {
                Tick();
            }
        }

        private void Update()
        {
            if (!_isRunning || _isPaused)
                return;

            if (tickInterval <= 0f)
            {
                tickInterval = 0.01f;
            }

            _elapsedTime += Time.deltaTime * _timeScale;

            while (_elapsedTime >= tickInterval)
            {
                _elapsedTime -= tickInterval;
                Tick();
            }
        }

        private void Tick()
        {
            int previousDay = currentDay;

            currentTick++;

            if (enableDebugLog && logEveryTick)
            {
                Debug.Log(
                    $"[TickManager] Tick={currentTick}, Day={currentDay}, TickInDay={tickInDay}, Registered={_tickables.Count}",
                    this);
            }

            _tickableSnapshot.Clear();
            _tickableSnapshot.AddRange(_tickables);

            for (int i = 0; i < _tickableSnapshot.Count; i++)
            {
                ITickable tickable = _tickableSnapshot[i];

                if (tickable == null)
                    continue;

                if (!_tickables.Contains(tickable))
                    continue;

                tickable.OnTick(currentTick);
            }

            OnTicked?.Invoke(currentTick);

            if (currentDay != previousDay)
            {
                OnDayChanged?.Invoke(currentDay);
                Log($"DayChanged: Day={currentDay}");
            }
        }

        private void ClampSettings()
        {
            tickInterval = Mathf.Max(0.01f, tickInterval);
            ticksPerDay = Mathf.Max(1, ticksPerDay);
            _timeScale = Mathf.Max(0.1f, _timeScale);
        }

        private void Log(string message)
        {
            if (!enableDebugLog)
                return;

            Debug.Log($"[TickManager] {message}", this);
        }
    }
}