﻿using System;
using System.Collections.Generic;
using System.IO;
using Data;
using Runtime;
using UnityEngine;

namespace Core
{
    public class SaveManager
    {
        private const string SaveFileName = "save_data.json";

        public string SavePath { get; private set; }
        public GameSaveData CurrentSaveData { get; private set; }

        private readonly EconomyManager economyManager;
        private readonly Inventory.Inventory inventory;
        private readonly Farm.FarmGrid farmGrid;
        private readonly TickManager tickManager;

        private readonly Dictionary<string, ItemData> itemDatabase;
        private readonly Dictionary<string, CropData> cropDatabase;

        public SaveManager(
            EconomyManager economyManager,
            Inventory.Inventory inventory,
            Farm.FarmGrid farmGrid,
            TickManager tickManager,
            Dictionary<string, ItemData> itemDatabase = null,
            Dictionary<string, CropData> cropDatabase = null)
        {
            this.economyManager = economyManager;
            this.inventory = inventory;
            this.farmGrid = farmGrid;
            this.tickManager = tickManager;

            this.itemDatabase = itemDatabase;
            this.cropDatabase = cropDatabase;

            SavePath = Path.Combine(Application.persistentDataPath, SaveFileName);
            CurrentSaveData = CreateSaveData();
        }

        public void SaveGame()
        {
            try
            {
                CurrentSaveData = CreateSaveData();

                string json = JsonUtility.ToJson(CurrentSaveData, true);

                string directory = Path.GetDirectoryName(SavePath);
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                File.WriteAllText(SavePath, json);

                Debug.Log($"Save Complete: {SavePath}");
            }
            catch (Exception ex)
            {
                Debug.LogError($"Save Failed: {ex.Message}");
            }
        }

        public void LoadGame()
        {
            try
            {
                if (!HasSaveFile())
                {
                    Debug.LogWarning("Save file not found.");
                    CurrentSaveData = CreateSaveData();
                    return;
                }

                string json = File.ReadAllText(SavePath);

                if (string.IsNullOrWhiteSpace(json))
                {
                    Debug.LogWarning("Save file is empty.");
                    CurrentSaveData = CreateSaveData();
                    return;
                }

                GameSaveData loadedData = JsonUtility.FromJson<GameSaveData>(json);

                if (loadedData == null)
                {
                    Debug.LogWarning("Save data parse failed.");
                    CurrentSaveData = CreateSaveData();
                    return;
                }

                CurrentSaveData = loadedData;
                ApplySaveData(CurrentSaveData);

                Debug.Log($"Load Complete: {SavePath}");
            }
            catch (Exception ex)
            {
                Debug.LogError($"Load Failed: {ex.Message}");
                CurrentSaveData = CreateSaveData();
            }
        }

        public bool HasSaveFile()
        {
            return File.Exists(SavePath);
        }

        public void DeleteSave()
        {
            try
            {
                if (!HasSaveFile())
                {
                    Debug.LogWarning("Save file does not exist.");
                    return;
                }

                File.Delete(SavePath);
                CurrentSaveData = CreateSaveData();

                Debug.Log($"Save Deleted: {SavePath}");
            }
            catch (Exception ex)
            {
                Debug.LogError($"Delete Save Failed: {ex.Message}");
            }
        }

        private GameSaveData CreateSaveData()
        {
            GameSaveData data = new GameSaveData
            {
                saveVersion = 1,
                savedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            if (tickManager != null)
            {
                data.currentTick = tickManager.currentTick;
                data.currentDay = tickManager.currentDay;
            }

            if (economyManager != null)
            {
                data.gold = economyManager.Gold;
            }

            if (inventory != null)
            {
                data.inventorySlots = inventory.CreateSaveData();
            }

            if (farmGrid != null)
            {
                data.fieldTiles = farmGrid.CreateSaveData();
            }

            return data;
        }

        private void ApplySaveData(GameSaveData data)
        {
            if (data == null)
            {
                Debug.LogWarning("ApplySaveData failed. Data is null.");
                return;
            }

            if (tickManager != null)
            {
                tickManager.LoadFromSaveData(data.currentTick, data.currentDay);
            }

            if (economyManager != null)
            {
                economyManager.SetGold(data.gold);
            }

            if (inventory != null)
            {
                if (itemDatabase != null)
                {
                    inventory.LoadFromSaveData(data.inventorySlots, itemDatabase);
                }
                else
                {
                    Debug.LogWarning("Item database is null. Inventory load skipped.");
                }
            }

            if (farmGrid != null)
            {
                if (cropDatabase != null)
                {
                    farmGrid.LoadFromSaveData(data.fieldTiles, cropDatabase);
                }
                else
                {
                    Debug.LogWarning("Crop database is null. FarmGrid load skipped.");
                }
            }
        }
    }
}