﻿namespace Systems.Interfaces
{
    public interface ITickable
    {
        public void OnTick(int currentTick);
    }
}