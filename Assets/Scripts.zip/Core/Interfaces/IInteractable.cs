﻿namespace Core.Interfaces
{
    public interface IInteractable
    {
        
    }
}