﻿using UnityEngine;

namespace Data
{
    public enum ItemType
    {
        None,
        Seed,
        Crop,
        Tool,
        Consumable,
        Misc
    }

    [CreateAssetMenu(fileName = "ItemData_", menuName = "Inventory/Item Data")]
    public class ItemData : ScriptableObject
    {
        [SerializeField] private string itemId;
        [SerializeField] private string itemName;
        [SerializeField] private ItemType itemType;
        [SerializeField] private int maxStack = 99;
        [SerializeField] private int buyPrice = 0;
        [SerializeField] private int sellPrice = 0;
        [SerializeField] private Sprite icon;

        public string ItemId => itemId;
        public string ItemName => itemName;
        public ItemType ItemType => itemType;
        public int MaxStack => maxStack;
        public int BuyPrice => buyPrice;
        public int SellPrice => sellPrice;
        public Sprite Icon => icon;

        public bool CanStackWith(ItemData other)
        {
            if (other == null) return false;
            return itemId == other.itemId && maxStack > 1;
        }

        private void OnValidate()
        {
            if (maxStack < 1) maxStack = 1;
            if (buyPrice < 0) buyPrice = 0;
            if (sellPrice < 0) sellPrice = 0;
        }
    }
}