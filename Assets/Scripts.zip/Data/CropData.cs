﻿using Data;
using UnityEngine;

namespace Data
{
    [CreateAssetMenu(fileName = "CropData_", menuName = "Farm/Crop Data")]
    public class CropData : ScriptableObject
    {
        [Header("Basic Info")]
        [SerializeField] private string cropId;
        [SerializeField] private string cropName;

        [Header("Growth")]
        [SerializeField] private int totalGrowthStage = 4;
        [SerializeField] private int ticksPerStage = 10;
        [SerializeField] private Sprite[] stageSprites;

        [Header("Economy")]
        [SerializeField] private int buyPrice = 10;
        [SerializeField] private int sellPrice = 20;

        [Header("Harvest")]
        [SerializeField] private ItemData harvestItem;

        public string CropId => cropId;
        public string CropName => cropName;
        public ItemData HarvestItem => harvestItem;

        public int GetGrowthTicks()
        {
            return ticksPerStage;
        }

        public int GetTotalGrowthTicks()
        {
            return totalGrowthStage * ticksPerStage;
        }

        public int GetTotalGrowthStage()
        {
            return totalGrowthStage;
        }

        public int GetBuyPrice()
        {
            return buyPrice;
        }

        public int GetSellPrice()
        {
            return sellPrice;
        }

        public Sprite GetSprite(int stage)
        {
            if (stageSprites == null || stageSprites.Length == 0)
                return null;

            int maxIndex = Mathf.Min(stageSprites.Length, totalGrowthStage) - 1;
            stage = Mathf.Clamp(stage, 0, maxIndex);
            return stageSprites[stage];
        }

        private void OnValidate()
        {
            if (totalGrowthStage < 1)
                totalGrowthStage = 1;

            if (ticksPerStage < 1)
                ticksPerStage = 1;

            if (buyPrice < 0)
                buyPrice = 0;

            if (sellPrice < 0)
                sellPrice = 0;
        }
    }
}