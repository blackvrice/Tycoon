﻿using System;
using UnityEngine;

namespace Data
{
    [Serializable]
    public class ShopItemData
    {
        [SerializeField] private ItemData item;
        [SerializeField] private int buyPrice;
        [SerializeField] private int sellPrice;
        [SerializeField] private bool isUnlocked = true;

        public ItemData Item => item;
        public int BuyPrice => buyPrice;
        public int SellPrice => sellPrice;
        public bool IsUnlocked => isUnlocked;
    }
}