﻿namespace Network
{
    public class ReplicationSystem
    {
        
    }
}