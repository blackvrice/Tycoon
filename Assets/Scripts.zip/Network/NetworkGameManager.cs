﻿namespace Network
{
    public class NetworkGameManager
    {
        
    }
}