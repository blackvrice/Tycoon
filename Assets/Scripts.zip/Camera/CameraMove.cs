using UnityEngine;

namespace Camera
{
    public class CameraMove : MonoBehaviour
    {
        [SerializeField] private Transform target;
        [SerializeField] private Vector3 offset = new Vector3(0f, 0f, -10f);

        private void LateUpdate()
        {
            if (target == null) return;
            transform.position = target.position + offset;
        }
    
    }
}