﻿using System;
using Data;

namespace Shop
{
    public class ShopItemEntry
    {
        public ItemData Item { get; }
        public int BuyPrice { get; }
        public int SellPrice { get; }
        public bool IsUnlocked { get; private set; }

        public ShopItemEntry(ShopItemData data)
        {
            if (data == null)
                throw new ArgumentNullException(nameof(data));

            if (data.Item == null)
                throw new ArgumentNullException(nameof(data.Item));

            Item = data.Item;
            BuyPrice = data.BuyPrice;
            SellPrice = data.SellPrice;
            IsUnlocked = data.IsUnlocked;
        }

        public void Unlock()
        {
            IsUnlocked = true;
        }

        public void Lock()
        {
            IsUnlocked = false;
        }
    }
}