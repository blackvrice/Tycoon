﻿using System.Collections.Generic;
using Core;
using Data;
using Inventory;

namespace Shop
{
    public class ShopSystem
    {
        private readonly List<ShopItemEntry> _itemsForSale;
        private readonly EconomyManager _economyManager;
        private readonly Inventory.Inventory _playerInventory;

        public ShopSystem(
            List<ShopItemEntry> itemsForSale,
            EconomyManager economyManager,
            Inventory.Inventory playerInventory)
        {
            _itemsForSale = itemsForSale ?? new List<ShopItemEntry>();
            _economyManager = economyManager;
            _playerInventory = playerInventory;
        }

        public bool BuyItem(ItemData item, int amount)
        {
            if (!CanBuy(item, amount)) return false;

            int totalPrice = GetBuyPrice(item) * amount;

            if (!_economyManager.SpendGold(totalPrice))
                return false;

            bool added = _playerInventory.AddItem(new ItemStack(item, amount), amount);
            if (!added)
            {
                // 실패 시 골드 복구
                _economyManager.AddGold(totalPrice);
                return false;
            }

            return true;
        }

        public bool SellItem(ItemData item, int amount)
        {
            if (!CanSell(item, amount)) return false;

            bool removed = _playerInventory.RemoveItem(item, amount);
            if (!removed) return false;

            int totalPrice = GetSellPrice(item) * amount;
            _economyManager.AddGold(totalPrice);

            return true;
        }

        public int GetBuyPrice(ItemData item)
        {
            if (item == null) return -1;

            ShopItemEntry entry = FindEntry(item);
            if (entry == null) return -1;

            return entry.BuyPrice;
        }

        public int GetSellPrice(ItemData item)
        {
            if (item == null) return -1;

            ShopItemEntry entry = FindEntry(item);
            if (entry != null)
                return entry.SellPrice;

            // 상점 목록에 없어도 아이템 기본 판매가 사용 가능
            return item.SellPrice;
        }

        public bool CanBuy(ItemData item, int amount)
        {
            if (item == null || amount <= 0) return false;

            ShopItemEntry entry = FindEntry(item);
            if (entry == null) return false;

            int totalPrice = entry.BuyPrice * amount;
            if (totalPrice < 0) return false;

            if (!_economyManager.CanAfford(totalPrice))
                return false;

            if (!CanReceiveItem(item, amount))
                return false;

            return true;
        }

        public bool CanSell(ItemData item, int amount)
        {
            if (item == null || amount <= 0) return false;
            if (GetSellPrice(item) < 0) return false;

            return _playerInventory.HasItem(item, amount);
        }

        private ShopItemEntry FindEntry(ItemData item)
        {
            if (item == null) return null;

            for (int i = 0; i < _itemsForSale.Count; i++)
            {
                if (_itemsForSale[i] == null) continue;
                if (_itemsForSale[i].Item == item)
                    return _itemsForSale[i];
            }

            return null;
        }

        private bool CanReceiveItem(ItemData item, int amount)
        {
            if (item == null || amount <= 0) return false;

            int remaining = amount;

            foreach (InventorySlot slot in _playerInventory.slots)
            {
                if (slot.IsEmpty())
                {
                    remaining -= item.MaxStack;
                }
                else if (slot.stack.itemData == item)
                {
                    remaining -= (item.MaxStack - slot.stack.amount);
                }

                if (remaining <= 0)
                    return true;
            }

            return false;
        }
    }
}