using System;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;

namespace Input
{
    public class InputManager : MonoBehaviour
    {
        public event Action<Vector2> MoveEvent;
        public event Action<int> SelectHotbarEvent;
        public event Action<int> ScrollHotbarEvent;

        public void OnMove(InputAction.CallbackContext context)
        {
            Debug.Log("OnMove");
            if (context.canceled)
            {
                MoveEvent?.Invoke(Vector2.zero);
                return;
            }

            MoveEvent?.Invoke(context.ReadValue<Vector2>());
        }

        public void OnSelectHotbarSlot(InputAction.CallbackContext context)
        {
            if (!context.performed)
                return;

            if (context.control is not KeyControl key)
                return;

            int slotIndex = key.keyCode switch
            {
                Key.Digit1 or Key.Numpad1 => 0,
                Key.Digit2 or Key.Numpad2 => 1,
                Key.Digit3 or Key.Numpad3 => 2,
                Key.Digit4 or Key.Numpad4 => 3,
                Key.Digit5 or Key.Numpad5 => 4,
                Key.Digit6 or Key.Numpad6 => 5,
                Key.Digit7 or Key.Numpad7 => 6,
                Key.Digit8 or Key.Numpad8 => 7,
                Key.Digit9 or Key.Numpad9 => 8,
                _ => -1
            };

            if (slotIndex >= 0)
                SelectHotbarEvent?.Invoke(slotIndex);
        }
        
        public void OnScrollHotbar(InputAction.CallbackContext context)
        {
            if (!context.performed)
                return;

            float scrollY = context.ReadValue<Vector2>().y;

            if (scrollY > 0f)
                ScrollHotbarEvent?.Invoke(-1);
            else if (scrollY < 0f)
                ScrollHotbarEvent?.Invoke(1);
        }
    }
}